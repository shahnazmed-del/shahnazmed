import React, { useState, useEffect, useMemo } from "react";
import { 
  Search, 
  MapPin, 
  ShieldCheck, 
  ShoppingBag, 
  Instagram,
  Facebook, 
  Twitter, 
  CheckCircle2, 
  Star, 
  Sparkles,
  PhoneCall,
  X,
  Filter,
  PackageCheck
} from "lucide-react";

import { STORE_INFO, STORE_PRODUCTS, INSTORE_ADVANTAGES, CUSTOMER_REVIEWS } from "./data";
import { CartItem, Product, ColorOption, ProductCategory } from "./types";

import SMedLogo from "./components/SMedLogo";
import HeroSection from "./components/HeroSection";
import ProductCard from "./components/ProductCard";
import ProductDetailsModal from "./components/ProductDetailsModal";
import CartDrawer from "./components/CartDrawer";
import ContactSection from "./components/ContactSection";

export default function App() {
  // Local state managers
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [activeModalProduct, setActiveModalProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load previous cart selections securely on startup
  useEffect(() => {
    const savedCart = localStorage.getItem("shahnaz_med_cart_v1");
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (e) {
        console.error("Failed to load saved cart state.", e);
      }
    }
  }, []);

  // Sync state back to local database
  const saveCartToStorage = (updatedCart: CartItem[]) => {
    setCart(updatedCart);
    localStorage.setItem("shahnaz_med_cart_v1", JSON.stringify(updatedCart));
  };

  // Show premium temporary toast alert feedback
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Handler: Add customized product to checkout cart
  const handleAddToCart = (product: Product, size: string, color: ColorOption, quantity: number) => {
    const itemId = `${product.id}-${size}-${color.name}`;
    const existingIndex = cart.findIndex((item) => item.id === itemId);

    let updatedCart: CartItem[];
    if (existingIndex > -1) {
      // Increment existing selection
      const newItems = [...cart];
      newItems[existingIndex].quantity += quantity;
      updatedCart = newItems;
    } else {
      // Add fresh cart selection
      const newItem: CartItem = {
        id: itemId,
        product,
        selectedSize: size,
        selectedColor: color,
        quantity
      };
      updatedCart = [...cart, newItem];
    }

    saveCartToStorage(updatedCart);
    triggerToast(`Added ${quantity}x ${product.name} to cart!`);
  };

  // Quick Action Handler: Add default product straight from listings
  const handleAddDefaultToCart = (product: Product, size: string) => {
    const color = product.colors[0]; // grab default Midnight/Sport accent
    handleAddToCart(product, size, color, 1);
  };

  // Handler: Modulate count indices in sidebar tray
  const handleUpdateCartQty = (itemId: string, newQty: number) => {
    let updatedCart: CartItem[];
    if (newQty <= 0) {
      updatedCart = cart.filter((item) => item.id !== itemId);
    } else {
      updatedCart = cart.map((item) => 
        item.id === itemId ? { ...item, quantity: newQty } : item
      );
    }
    saveCartToStorage(updatedCart);
  };

  // Handler: Expel items entirely from cart index
  const handleRemoveCartItem = (itemId: string) => {
    const updatedCart = cart.filter((item) => item.id !== itemId);
    saveCartToStorage(updatedCart);
    triggerToast("Item removed from your cart.");
  };

  // Calculate cart count dynamically
  const cartItemCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // Derived state: filtered products based on category buttons and search string
  const filteredProducts = useMemo(() => {
    return STORE_PRODUCTS.filter((product) => {
      const matchCategory = selectedCategory === "All" || product.category === selectedCategory;
      const matchSearch = 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCategory && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  // Page Scroll CTA helpers
  const handleScrollToGrid = () => {
    const element = document.getElementById("catalog-grid-destination");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  const handleScrollToContact = () => {
    const element = document.getElementById("contact-info-section");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col justify-between selection:bg-sport-blue/20 selection:text-sport-blue" id="shahnazmed-app-root">
      
      {/* Toast Alert Notice Popup */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-800 text-white px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 animate-fade-in font-display uppercase tracking-wider text-xs">
          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 animate-pulse" />
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="ml-2 hover:text-sport-red text-slate-400">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Header element */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 sm:h-20 flex items-center justify-between">
          
          {/* Brand Logo - replica */}
          <a href="#" className="flex items-center">
            <SMedLogo size="md" />
          </a>

          {/* Navigation Links (Strictly human and helpful, no junk clutter) */}
          <nav className="hidden md:flex items-center gap-8 text-xs font-black uppercase tracking-wider text-slate-500 font-display">
            <button 
              onClick={handleScrollToGrid} 
              className="hover:text-sport-blue transition-colors cursor-pointer"
            >
              Support Catalog
            </button>
            <span className="h-1.5 w-1.5 rounded-full bg-slate-200" />
            <a 
              href="#instore-advantages-section" 
              className="hover:text-sport-blue transition-colors cursor-pointer"
            >
              Why S+Med
            </a>
            <span className="h-1.5 w-1.5 rounded-full bg-slate-200" />
            <a 
              href="#testimonials-section" 
              className="hover:text-sport-blue transition-colors cursor-pointer"
            >
              Athlete Feedback
            </a>
            <span className="h-1.5 w-1.5 rounded-full bg-slate-200" />
            <button 
              onClick={handleScrollToContact} 
              className="hover:text-sport-blue transition-colors cursor-pointer"
            >
              Srinagar Clinic
            </button>
          </nav>

          {/* Checkout Cart Indicator trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative h-11 w-11 sm:h-12 sm:w-12 bg-slate-950 hover:bg-sport-blue text-white rounded-2xl flex items-center justify-center transition-all cursor-pointer shadow-md group border border-slate-900"
            id="header-cart-trigger"
            aria-label="Toggle Shopping Cart"
          >
            <ShoppingBag className="h-5 w-5 transform group-hover:scale-105 transition-transform" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-sport-red text-white text-[10px] font-black h-5.5 w-5.5 rounded-full flex items-center justify-center border-2 border-white font-display shadow-sm">
                {cartItemCount}
              </span>
            )}
          </button>

        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* Banner Segment */}
        <HeroSection 
          onExploreProducts={handleScrollToGrid} 
          onContactClick={handleScrollToContact} 
        />

        {/* Instore Advantages section */}
        <section 
          className="py-12 sm:py-16 bg-white border-b border-slate-100" 
          id="instore-advantages-section"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {INSTORE_ADVANTAGES.map((adv, index) => (
                <div 
                  key={index} 
                  className="bg-slate-50 border border-slate-100 p-5 rounded-3xl space-y-2 hover:border-slate-250 transition-colors"
                >
                  <div className="h-8 w-8 rounded-lg bg-sport-blue/10 flex items-center justify-center border border-sport-blue/20 text-sport-blue font-black font-display text-sm">
                    0{index + 1}
                  </div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-950 font-display">
                    {adv.title}
                  </h3>
                  <p className="text-slate-500 text-xs leading-relaxed font-sans">
                    {adv.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Primary Product Showcase and Search / Filter segment */}
        <section 
          className="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20" 
          id="catalog-grid-destination"
        >
          {/* Module Header titles */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-sport-blue bg-sport-blue/5 border border-sport-blue/15 px-3 py-1 rounded-md inline-block font-display">
                Elite Catalog
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-950 font-display uppercase">
                Browse Protective Support Gear
              </h2>
              <p className="text-slate-500 text-xs sm:text-sm">
                Choose the support level customized to your current injury recovery path or lifting regime.
              </p>
            </div>

            {/* In-stock status indicator */}
            <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-100 px-3.5 py-1.5 rounded-xl self-start md:self-auto">
              <span className="h-2 w-2 rounded-full bg-emerald-550 animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 font-display">
                Showroom fully stocked (100% genuine)
              </span>
            </div>
          </div>

          {/* Filtering row + Searching input tools */}
          <div className="bg-white rounded-3xl border border-slate-150/80 p-4 mb-8 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 shadow-xs">
            
            {/* Category selection bar */}
            <div className="flex flex-wrap items-center gap-1.5 order-2 lg:order-1">
              {["All", "Orthopedic Supports", "Spine & Neck Care", "Gym & Fitness Gear"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 text-[11px] font-black uppercase tracking-wider font-display rounded-xl border transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? "bg-slate-950 border-slate-950 text-white font-black"
                      : "bg-slate-50 border-slate-200/60 text-slate-600 hover:border-slate-300"
                  }`}
                >
                  {cat === "All" ? "All Gear" : cat}
                </button>
              ))}
            </div>

            {/* Keyword searching field */}
            <div className="relative order-1 lg:order-2 max-w-sm w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search knee caps, gym gloves, wrist wrap..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-slate-950 focus:bg-white focus:ring-0 pl-10 pr-9 py-2.5 rounded-xl transition-all font-sans text-slate-950"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 flex items-center justify-center text-slate-400 hover:text-slate-900 cursor-pointer"
                  title="Clear input query"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>

          </div>

          {/* Catalog grid displaying dynamic output cards */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-3xl border border-slate-100 max-w-lg mx-auto space-y-4">
              <div className="h-16 w-16 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center mx-auto text-slate-400">
                <Filter className="h-6 w-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 font-display">No support items matched</h3>
                <p className="text-xs text-slate-400 max-w-xs mx-auto leading-normal">
                  No products match your active search terms or category parameters. Try resetting filters.
                </p>
              </div>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("All");
                }}
                className="sport-gradient-blue text-white text-xs font-bold uppercase tracking-wider font-display px-5 py-2.5 rounded-xl hover:opacity-95 shadow-xs cursor-pointer"
              >
                Reset Store Guides
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((product) => (
                <ProductCard 
                  key={product.id}
                  product={product}
                  onViewDetails={setActiveModalProduct}
                  onAddToCart={handleAddDefaultToCart}
                />
              ))}
            </div>
          )}

        </section>

        {/* Customer Reviews section */}
        <section 
          className="bg-slate-950 text-white py-16 sm:py-24 border-y border-slate-800" 
          id="testimonials-section"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            {/* Module Headings */}
            <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
              <span className="text-[10px] font-black uppercase tracking-widest text-sport-blue bg-sport-blue/10 border border-sport-blue/25 px-3 py-1 rounded-md inline-block font-display">
                Field Tested
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display uppercase tracking-tight">
                athlete and physician feedback
              </h2>
              <p className="text-slate-450 text-sm leading-relaxed">
                Hear from J&K mountain trekkers, weights athletes, and medical physiotherapists who trust Shahnaz Med's supports daily.
              </p>
            </div>

            {/* Testimonials cards grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {CUSTOMER_REVIEWS.map((review) => (
                <div 
                  key={review.id} 
                  className="bg-slate-900 border border-slate-800 p-6 sm:p-8 rounded-3xl relative flex flex-col justify-between hover:border-slate-700 transition-colors"
                >
                  <div className="space-y-4">
                    {/* Stars bar */}
                    <div className="flex gap-0.5 text-amber-500">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-amber-500 stroke-none" />
                      ))}
                    </div>

                    <blockquote className="text-slate-300 text-sm leading-relaxed font-sans italic">
                      "{review.comment}"
                    </blockquote>
                  </div>

                  {/* Profile bio */}
                  <div className="flex items-center justify-between border-t border-slate-800/80 pt-4 mt-6">
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-white font-display">
                        {review.author}
                      </h4>
                      <p className="text-[10px] text-slate-500 font-sans mt-0.5">
                        {review.location}
                      </p>
                    </div>

                    <span className="bg-sport-blue/10 border border-sport-blue/30 text-sport-blue text-[9px] font-extrabold uppercase tracking-wide px-2.5 py-1 rounded-md font-display">
                      {review.activity}
                    </span>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </section>

        {/* Contact details and Fitting Callback inquiry formulary */}
        <ContactSection />

      </main>

      {/* Footer Element */}
      <footer className="bg-slate-950 text-slate-300 border-t border-slate-900 py-12 select-none" id="shahnazmed-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start mb-8 pb-8 border-b border-slate-900">
            
            {/* Logo description block */}
            <div className="md:col-span-5 space-y-4">
              <SMedLogo size="lg" lightText={true} />
              
              <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
                Orthopedic supports designed to maintain active, pain-free athletic performance across Kashmir. Central hub in Lal Chowk, Srinagar, Jammu & Kashmir.
              </p>

              {/* Direct helpline calls */}
              <div className="text-slate-205 flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse inline-block" />
                <span className="text-xs font-bold font-display uppercase">Store Hotline: </span>
                <a href={`tel:${STORE_INFO.phone}`} className="text-sm font-black text-white hover:text-sport-blue tracking-tight transition-colors font-display">
                  +91 {STORE_INFO.phone}
                </a>
              </div>
            </div>

            {/* Navigation links block */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-white font-display">
                Support Items
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-400">
                <li><button onClick={handleScrollToGrid} className="hover:text-white transition-colors cursor-pointer text-left">ForceGrip Wrist wraps</button></li>
                <li><button onClick={handleScrollToGrid} className="hover:text-white transition-colors cursor-pointer text-left">ActiveShield Knee sleeves</button></li>
                <li><button onClick={handleScrollToGrid} className="hover:text-white transition-colors cursor-pointer text-left">PostureGuard Cervical pillow</button></li>
                <li><button onClick={handleScrollToGrid} className="hover:text-white transition-colors cursor-pointer text-left">ProCombat gym gloves</button></li>
                <li><button onClick={handleScrollToGrid} className="hover:text-white transition-colors cursor-pointer text-left">KineticLock Ankle stabilizers</button></li>
              </ul>
            </div>

            {/* Address coords block */}
            <div className="md:col-span-4 space-y-3">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-white font-display">
                Showroom Coordinates
              </h4>
              <p className="text-xs text-slate-400 leading-normal max-w-xs font-sans">
                {STORE_INFO.location} <br />
                Jammu & Kashmir, India
              </p>
              
              {/* Direct email links */}
              <a href={`mailto:${STORE_INFO.email}`} className="text-xs font-medium text-sport-blue hover:underline block font-sans">
                {STORE_INFO.email}
              </a>
            </div>

          </div>

          {/* Copyright signature */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 font-sans">
            <p>© {new Date().getFullYear()} Shahnaz Med, Srinagar J&K. All Rights Reserved.</p>
            <div className="flex items-center gap-4">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <span className="h-3 w-px bg-slate-800" />
              <a href="#" className="hover:text-white transition-colors">Fitting Manuals</a>
            </div>
          </div>

        </div>
      </footer>

      {/* Slide Drawer Tray holding active Cart Items */}
      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
      />

      {/* Dynamic Modal representing product customizer choices */}
      {activeModalProduct && (
        <ProductDetailsModal 
          product={activeModalProduct}
          onClose={() => setActiveModalProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

    </div>
  );
}
