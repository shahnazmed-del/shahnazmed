import React, { useState } from "react";
import { X, Trash2, ShoppingBag, ArrowRight, MessageSquare, Mail, PhoneCall, HelpCircle } from "lucide-react";
import { CartItem, ColorOption } from "../types";
import { STORE_INFO } from "../data";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQty: (itemId: string, qty: number) => void;
  onRemoveItem: (itemId: string) => void;
}

export default function CartDrawer({ isOpen, onClose, cartItems, onUpdateQty, onRemoveItem }: CartDrawerProps) {
  const [checkoutName, setCheckoutName] = useState("");
  const [checkoutPhone, setCheckoutPhone] = useState("");
  const [checkoutAddress, setCheckoutAddress] = useState("");
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryCharge = subtotal > 1000 ? 0 : 80; // Free delivery across J&K above ₹1000!
  const total = subtotal + deliveryCharge;

  // Format order for WhatsApp and create native integration
  const handlePlaceOrderWhatsApp = () => {
    if (!checkoutName || !checkoutPhone || !checkoutAddress) {
      alert("Please fill in your Delivery Name, Phone Number, and complete Address before completing checkout.");
      return;
    }

    // Build plain-text structured receipt
    let message = `*🔴 SHAHNAZ MED - ORDER REQUEST*\n`;
    message += `===================================\n`;
    message += `*Customer Details:*\n`;
    message += `👤 Name: ${checkoutName}\n`;
    message += `📞 Phone: ${checkoutPhone}\n`;
    message += `📍 Delivery Address: ${checkoutAddress}\n`;
    message += `===================================\n\n`;
    message += `*Items Ordered:*\n`;

    cartItems.forEach((item, index) => {
      message += `${index + 1}. *${item.product.name}*\n`;
      message += `   📏 Size: ${item.selectedSize}\n`;
      message += `   🎨 Color: ${item.selectedColor.name}\n`;
      message += `   🔢 Qty: ${item.quantity} x ₹${item.product.price}\n`;
      message += `   💰 Subtotal: ₹${item.product.price * item.quantity}\n\n`;
    });

    message += `===================================\n`;
    message += `*Order Summary:*\n`;
    message += `🔹 Subtotal: ₹${subtotal}\n`;
    message += `🔹 Delivery: ${deliveryCharge === 0 ? "FREE" : `₹${deliveryCharge}`}\n`;
    message += `🏆 *TOTAL DUE: ₹${total}*\n`;
    message += `===================================\n\n`;
    message += `_This order request was generated from Shahnaz Med web app portal (Srinagar, J&K). Veuillez confirm stock and dispatch schedule._`;

    const encodedText = encodeURIComponent(message);
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${STORE_INFO.phone}&text=${encodedText}`;
    
    // Redirect securely
    window.open(whatsappUrl, "_blank");
  };

  // Compile clean email template
  const handlePlaceOrderEmail = () => {
    if (!checkoutName || !checkoutPhone || !checkoutAddress) {
      alert("Please fill in your Delivery Name, Phone Number, and complete Address before completing checkout.");
      return;
    }

    const subject = `New Product Order - ${checkoutName} (${checkoutPhone})`;
    let body = `Dear Shahnaz Med,\n\n`;
    body += `I would like to place an order for the following recovery and sports supports:\n\n`;
    body += `-------------------------------------------------\n`;
    body += `CUSTOMER DELEVERY DETAILS:\n`;
    body += `Name: ${checkoutName}\n`;
    body += `Phone: ${checkoutPhone}\n`;
    body += `Address: ${checkoutAddress}\n`;
    body += `-------------------------------------------------\n\n`;
    
    cartItems.forEach((item, index) => {
      body += `${index + 1}. ${item.product.name}\n`;
      body += `   Size: ${item.selectedSize} | Color: ${item.selectedColor.name}\n`;
      body += `   Qty: ${item.quantity} x Rs. ${item.product.price} = Rs. ${item.product.price * item.quantity}\n\n`;
    });

    body += `-------------------------------------------------\n`;
    body += `Subtotal: Rs. ${subtotal}\n`;
    body += `Local Delivery across J&K: Rs. ${deliveryCharge}\n`;
    body += `TOTAL ESTIMATED: Rs. ${total}\n`;
    body += `-------------------------------------------------\n\n`;
    body += `Please contact me to confirm the order dispatch and share payment details (UPI/Cash on Delivery).\n\n`;
    body += `Best Regards,\n`;
    body += `${checkoutName}`;

    const mailtoUrl = `mailto:${STORE_INFO.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoUrl, "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" id="cart-drawer-wrapper">
      {/* Dynamic Slide Drawer Container */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Backdrop overlay closely bound */}
        <div 
          className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity cursor-pointer animate-fade"
          onClick={onClose} 
        />

        <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-0 sm:pl-10">
          <div className="pointer-events-auto h-full w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-slate-100">
            
            {/* Drawer Header context */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="h-9 w-9 bg-sport-blue/10 rounded-xl flex items-center justify-center border border-sport-blue/20">
                  <ShoppingBag className="h-4.5 w-4.5 text-sport-blue" />
                </div>
                <div>
                  <h2 className="text-lg font-black text-slate-950 font-display uppercase tracking-tight">Your Cart</h2>
                  <p className="text-xs text-slate-400 font-medium">{cartItems.length} support item(s) selected</p>
                </div>
              </div>
              
              <button
                onClick={onClose}
                className="bg-slate-50 hover:bg-slate-100 p-2 rounded-xl text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Main Cart Items Scroll Container */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
                  <div className="relative h-20 w-20 rounded-full bg-slate-50 flex items-center justify-center border border-slate-100">
                    <ShoppingBag className="h-8 w-8 text-slate-350" />
                    <span className="absolute -top-1 -right-1 h-3 w-3 bg-sport-red rounded-full animate-ping" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 uppercase font-display tracking-tight">Your cart is empty</h3>
                    <p className="text-xs text-slate-400 max-w-xs mt-1 leading-normal">
                      No active supports or compression braces configured. Protect your joints by browsing our high-performance gear catalog.
                    </p>
                  </div>
                  <button
                    onClick={onClose}
                    className="sport-gradient-blue text-white text-xs font-bold uppercase tracking-wider font-display px-5 py-2.5 rounded-xl hover:opacity-90 shadow-xs cursor-pointer"
                  >
                    Browse Support Gear
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <div 
                      key={item.id}
                      className="flex items-center gap-4 bg-slate-50 border border-slate-100 p-3.5 rounded-2xl relative group hover:border-slate-250 transition-colors"
                    >
                      {/* Product Thumbnail */}
                      <div className="h-16 w-16 rounded-xl overflow-hidden bg-white border border-slate-100 shrink-0">
                        <img 
                          src={item.product.images[0]} 
                          alt={item.product.name} 
                          className="h-full w-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Info details */}
                      <div className="flex-1 space-y-1 min-w-0">
                        <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-tight truncate pr-6">
                          {item.product.name}
                        </h4>
                        
                        <div className="flex flex-wrap gap-1.5 text-[10px] text-slate-550 font-bold uppercase font-display">
                          <span className="bg-white border border-slate-200/60 px-1.5 py-0.5 rounded">
                            Size: {item.selectedSize}
                          </span>
                          <span className="bg-white border border-slate-200/60 px-1.5 py-0.5 rounded flex items-center gap-1">
                            <span 
                              className="h-2 w-2 rounded-full inline-block" 
                              style={{ backgroundColor: item.selectedColor.hex }} 
                            />
                            {item.selectedColor.name}
                          </span>
                        </div>

                        {/* Price & Incrementor block */}
                        <div className="flex items-center justify-between pt-1">
                          <span className="text-xs font-bold text-slate-950 font-display">
                            ₹{item.product.price} <span className="text-[10px] text-slate-405 font-medium font-sans">ea</span>
                          </span>

                          <div className="flex items-center border border-slate-250 bg-white rounded-lg overflow-hidden scale-90 origin-right">
                            <button
                              onClick={() => onUpdateQty(item.id, item.quantity - 1)}
                              className="px-2 py-0.5 bg-slate-50 hover:bg-slate-100 font-bold text-xs"
                            >
                              -
                            </button>
                            <span className="px-2.5 py-0.5 text-xs font-bold text-slate-900 font-display">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQty(item.id, item.quantity + 1)}
                              className="px-2 py-0.5 bg-slate-50 hover:bg-slate-100 font-bold text-xs"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Remove Button top right */}
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="absolute top-3.5 right-3.5 text-slate-350 hover:text-sport-red p-1 rounded-lg transition-colors cursor-pointer"
                        title="Remove support item"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Drawer Checkout & Summary Sticky Footer */}
            {cartItems.length > 0 && (
              <div className="p-6 border-t border-slate-100 bg-slate-50/50 space-y-4">
                
                {/* Checkout Fields Accordion / Open trigger */}
                {!isCheckingOut ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-900 font-display">
                      <span>Order Summary</span>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-600 bg-white p-3 rounded-2xl border border-slate-100">
                      <div className="flex justify-between">
                        <span>Items Subtotal</span>
                        <span className="font-semibold text-slate-900">₹{subtotal}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>J&K Courier Delivery</span>
                        <span className="font-semibold text-slate-900">{deliveryCharge === 0 ? "FREE" : `₹${deliveryCharge}`}</span>
                      </div>
                      {deliveryCharge > 0 && (
                        <div className="text-[10px] text-emerald-600 font-medium">Add ₹{1000 - subtotal} more for FREE shipping across Srinagar</div>
                      )}
                      <div className="flex justify-between border-t border-slate-100 pt-2 text-sm font-black text-slate-900 font-display uppercase">
                        <span>Total Due</span>
                        <span className="text-sport-blue">₹{total}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setIsCheckingOut(true)}
                      className="w-full sport-gradient-blue text-white hover:opacity-95 font-bold py-3.5 px-6 rounded-xl flex items-center justify-center gap-2.5 transition-all text-sm uppercase tracking-wider font-display cursor-pointer"
                    >
                      <span>Proceed to fitting & checkout</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4 animation-fade">
                    <div className="flex items-center justify-between border-b border-slate-150 pb-1.5">
                      <h3 className="text-xs font-black uppercase tracking-wider text-slate-905 font-display flex items-center gap-1.5">
                        <span className="h-2 w-2 rounded-full bg-sport-blue animate-pulse" />
                        Fitting & Delivery Info
                      </h3>
                      <button
                        onClick={() => setIsCheckingOut(false)}
                        className="text-[10px] font-bold text-sport-blue uppercase hover:underline cursor-pointer"
                      >
                        Back to Summary
                      </button>
                    </div>

                    {/* Form Fields input */}
                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] font-black uppercase tracking-wider text-slate-450 font-display mb-1">
                          Delivery Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={checkoutName}
                          onChange={(e) => setCheckoutName(e.target.value)}
                          placeholder="Zubair Ahmad"
                          className="w-full text-xs bg-white border border-slate-200 focus:border-slate-950 focus:ring-0 p-2.5 rounded-xl transition-all font-sans text-slate-950"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-black uppercase tracking-wider text-slate-450 font-display mb-1">
                          Active Contact Phone *
                        </label>
                        <input
                          type="tel"
                          required
                          value={checkoutPhone}
                          onChange={(e) => setCheckoutPhone(e.target.value)}
                          placeholder="9103681134"
                          className="w-full text-xs bg-white border border-slate-200 focus:border-slate-950 focus:ring-0 p-2.5 rounded-xl transition-all font-sans text-slate-950"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-black uppercase tracking-wider text-slate-450 font-display mb-1">
                          Complete Address J&K *
                        </label>
                        <textarea
                          rows={2}
                          required
                          value={checkoutAddress}
                          onChange={(e) => setCheckoutAddress(e.target.value)}
                          placeholder="House No 12, near Lal Chowk, Srinagar, Jammu & Kashmir"
                          className="w-full text-xs bg-white border border-slate-200 focus:border-slate-950 focus:ring-0 p-2.5 rounded-xl transition-all font-sans text-slate-950 resize-none"
                        />
                      </div>
                    </div>

                    {/* Integrated Dispatch Operators */}
                    <div className="space-y-2 pt-2.5">
                      <button
                        onClick={handlePlaceOrderWhatsApp}
                        className="w-full bg-[#25D366] hover:bg-[#20ba56] text-white font-bold py-3 px-5 rounded-xl flex items-center justify-center gap-2 transition-transform hover:scale-101 cursor-pointer font-display uppercase tracking-wider text-xs"
                      >
                        <MessageSquare className="h-4.5 w-4.5 shrink-0 fill-white stroke-none" />
                        <span>Confirm via WhatsApp (₹{total})</span>
                      </button>

                      <button
                        onClick={handlePlaceOrderEmail}
                        className="w-full bg-slate-950 hover:bg-slate-900 border border-transparent text-white font-semibold py-2.5 px-5 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer font-display uppercase tracking-wider text-[11px]"
                      >
                        <Mail className="h-4 w-4 shrink-0" />
                        <span>Send Email Order Enquiry</span>
                      </button>
                    </div>

                    {/* Kashmir Shipping Trust Banner */}
                    <div className="flex gap-2 items-start bg-blue-50/70 border border-blue-100 p-2.5 rounded-xl">
                      <HelpCircle className="h-3.5 w-3.5 text-sport-blue shrink-0 mt-0.5" />
                      <p className="text-[10px] text-slate-600 leading-normal">
                        <strong>Lal Chowk Counter Pickup:</strong> Skip delivery charges! Dial <strong>{STORE_INFO.phone}</strong> to reserve your support gear directly in-store.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
