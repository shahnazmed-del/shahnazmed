import React, { useState } from "react";
import { Phone, Mail, MapPin, Clock, Calendar, CheckCircle, MessageSquare, ArrowRight, ShieldCheck } from "lucide-react";
import { STORE_INFO } from "../data";
import { InquiryFormState } from "../types";

export default function ContactSection() {
  const [form, setForm] = useState<InquiryFormState>({
    name: "",
    phone: "",
    email: "",
    subject: "Fitting Consultation",
    message: ""
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Kashmir towns list for interactive travel estimation
  const transitRoutes = [
    { from: "Karan Nagar", dist: "2.4 km", time: "8 mins" },
    { from: "Sopore", dist: "48.2 km", time: "1 hr 12 mins" },
    { from: "Anantnag", dist: "52.8 km", time: "1 hr 15 mins" },
    { from: "Ganderbal", dist: "18.5 km", time: "30 mins" },
    { from: "Gulmarg", dist: "51.0 km", time: "1 hr 35 mins" }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.message) {
      alert("Please fill out Name, Phone and Question fields.");
      return;
    }

    // Direct WhatsApp enquiry compiler
    const emailSubject = `Product Support Enquiry - ${form.subject}`;
    let text = `*🔴 SHAHNAZ MED - SPECIALIST CONSULTATION*\n`;
    text += `===================================\n`;
    text += `👤 Sender: ${form.name}\n`;
    text += `📞 Phone: ${form.phone}\n`;
    text += `📧 Email: ${form.email || "Not Provided"}\n`;
    text += `🏷️ Topic: ${form.subject}\n`;
    text += `===================================\n\n`;
    text += `*Inquiry Message:*\n`;
    text += `"${form.message}"\n\n`;
    text += `===================================\n`;

    const encoded = encodeURIComponent(text);
    const whatsappQuery = `https://api.whatsapp.com/send?phone=${STORE_INFO.phone}&text=${encoded}`;
    
    // Simulate high success
    setIsSubmitted(true);
    setTimeout(() => {
      window.open(whatsappQuery, "_blank");
    }, 1500);
  };

  return (
    <section className="bg-slate-50 py-16 sm:py-24 border-t border-slate-100" id="contact-info-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-1.5 bg-sport-blue/10 text-sport-blue border border-sport-blue/20 text-[10px] font-black uppercase tracking-wider px-3.5 py-1 rounded-full font-display">
            <ShieldCheck className="h-3 w-3" />
            <span>Kashmir Ortho Support Center</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-950 font-display uppercase tracking-tight">
            Consult Srinagar Experts
          </h2>
          <p className="text-slate-500 text-sm leading-relaxed font-sans">
            Have questions about support sizing, compression levels, or recovering from a specific sports injury? Contact our Lal Chowk clinic team or schedule a fitting callback today.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Column 1: Contact Methods list & Srinagar showroom directions */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Direct Dial Box */}
            <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-950 font-display border-b border-slate-100 pb-3 block">
                Direct Contact Helpline
              </h3>
              
              <div className="space-y-4">
                {/* Phone */}
                <a 
                  href={`tel:${STORE_INFO.phone}`} 
                  className="flex gap-4 items-start p-2 hover:bg-slate-50 rounded-2xl transition-colors group"
                >
                  <div className="h-10 w-10 rounded-xl bg-sport-blue/5 border border-sport-blue/20 flex items-center justify-center shrink-0 group-hover:bg-sport-blue group-hover:text-white transition-all text-sport-blue">
                    <Phone className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-display">Ring Hotline</p>
                    <p className="text-sm font-extrabold text-slate-900 group-hover:text-sport-blue transition-colors font-display">+91 {STORE_INFO.phone}</p>
                    <p className="text-[11px] text-slate-500 font-sans">Call for bulk custom club requests</p>
                  </div>
                </a>

                {/* Email */}
                <a 
                  href={`mailto:${STORE_INFO.email}`} 
                  className="flex gap-4 items-start p-2 hover:bg-slate-50 rounded-2xl transition-colors group"
                >
                  <div className="h-10 w-10 rounded-xl bg-sport-red/5 border border-sport-red/20 flex items-center justify-center shrink-0 group-hover:bg-sport-red group-hover:text-white transition-all text-sport-red">
                    <Mail className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-display">Email Queries</p>
                    <p className="text-sm font-extrabold text-slate-900 group-hover:text-sport-red transition-colors font-display">{STORE_INFO.email}</p>
                    <p className="text-[11px] text-slate-500 font-sans">Expect replies within 12 working hours</p>
                  </div>
                </a>

                {/* Showroom location */}
                <div className="flex gap-4 items-start p-2">
                  <div className="h-10 w-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0 text-slate-600">
                    <MapPin className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-display">Visit Showroom</p>
                    <p className="text-xs font-black text-slate-900 font-display uppercase">{STORE_INFO.city}</p>
                    <p className="text-[11px] text-slate-500 leading-normal font-sans">{STORE_INFO.location}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Operating Times Box */}
            <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-950 font-display border-b border-slate-100 pb-3 flex items-center gap-2">
                <Clock className="h-4 w-4 text-sport-blue" />
                <span>Showroom Hours</span>
              </h3>
              
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between border-b border-slate-50 pb-1.5">
                  <span className="text-slate-500 font-medium font-sans">Monday - Saturday</span>
                  <span className="font-extrabold text-slate-900 font-display">09:30 AM - 07:00 PM</span>
                </div>
                <div className="flex justify-between border-b border-slate-50 pb-1.5 text-rose-600">
                  <span className="font-medium font-sans">Sundays</span>
                  <span className="font-black font-display uppercase">Appointments Only</span>
                </div>
                <p className="text-[10px] text-slate-400 italic text-center mt-2 pl-1 leading-normal font-sans text-left">
                  * Note: Power disruptions or heavy rainfall may limit in-store digital billing occasionally. Please call ahead during severe blocks.
                </p>
              </div>
            </div>

          </div>

          {/* Column 2: Consultation & fitting inquiry form */}
          <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-100 p-6 sm:p-8 shadow-xs">
            <h3 className="text-base font-black uppercase tracking-wider text-slate-950 font-display border-b border-slate-100 pb-3 block mb-4">
              Ask Our fitting Specialist
            </h3>

            {isSubmitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="h-14 w-14 rounded-full bg-emerald-550 text-white flex items-center justify-center mx-auto shadow-md">
                  <CheckCircle className="h-7 w-7" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 uppercase font-display">Consultation Form Routed!</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1 leading-relaxed">
                    Preparing direct secure chat link with Shahnaz Med specialist via WhatsApp catalog. Standby...
                  </p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-450 font-display mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Enter athlete/patient name"
                    className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-slate-950 focus:bg-white focus:ring-0 p-3 rounded-xl transition-all font-sans text-slate-950"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-450 font-display mb-1">
                    WhatsApp/Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="e.g. 9103681134"
                    className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-slate-950 focus:bg-white focus:ring-0 p-3 rounded-xl transition-all font-sans text-slate-950"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-450 font-display mb-1">
                    Topic of Consultation
                  </label>
                  <select
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-slate-950 focus:bg-white focus:ring-0 p-3 rounded-xl transition-all font-display text-slate-950 uppercase font-bold"
                  >
                    <option value="Fitting Consultation">Fitting & Size Selection</option>
                    <option value="Joint Injury Support">Knee/Wrist Injury Protection</option>
                    <option value="Spine Alignment advice">Cervical Pillow / Spine alignment</option>
                    <option value="Bulk Club Enquiries">Bulk gym orders (Srinagar)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-450 font-display mb-1">
                    Symptom description or Question *
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Detail your question. E.g., 'Do you have large size neoprene knee sleeves for active squats?'"
                    className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-slate-950 focus:bg-white focus:ring-0 p-3 rounded-xl transition-all font-sans text-slate-950 resize-none leading-relaxed"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full sport-gradient-blue text-white hover:opacity-95 font-bold py-3.5 px-6 rounded-xl flex items-center justify-center gap-2.5 transition-all text-xs uppercase tracking-wider font-display cursor-pointer"
                >
                  <MessageSquare className="h-4 w-4" />
                  <span>Send WhatsApp Inquiry</span>
                </button>
              </form>
            )}
          </div>

          {/* Column 3: Beautiful vector Regional Map of Kashmir & Transit estimations */}
          <div className="lg:col-span-4 bg-slate-900 text-white rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden border border-slate-800">
            <div className="absolute top-0 right-0 w-36 h-36 bg-sport-blue/15 rounded-full blur-2xl -z-1" />
            <div className="absolute bottom-0 left-0 w-36 h-36 bg-sport-red/10 rounded-full blur-2xl -z-1" />

            <div className="space-y-1 block relative z-10">
              <h3 className="text-sm font-black uppercase tracking-wider text-white font-display flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-sport-red animate-ping" />
                <span>Showroom Location Map</span>
              </h3>
              <p className="text-[11px] text-slate-400 font-sans">
                Positioned in Central Srinagar near iconic Lal Chowk landmark.
              </p>
            </div>

            {/* Micro Vector Map mockup of Srinagar Valley */}
            <div className="h-44 bg-slate-950/80 rounded-2xl relative border border-slate-800 overflow-hidden flex items-center justify-center p-3">
              <div className="absolute inset-0 opacity-[0.04] bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:16px_16px]" />
              
              {/* Srinagar Valley graphic layout */}
              <div className="relative w-full h-full">
                {/* stylized valleys mapping */}
                <svg className="absolute inset-0 w-full h-full opacity-15 stroke-slate-500 fill-none" viewBox="0 0 200 200">
                  <path d="M20 40 Q40 60 70 50 T120 90 T180 120" strokeWidth="2" strokeDasharray="3 3"/>
                  <path d="M10 120 Q50 90 90 130 T160 110" strokeWidth="1.5"/>
                  <circle cx="100" cy="100" r="45" strokeWidth="1" strokeDasharray="2 2"/>
                </svg>

                {/* Sopore / Baramulla node */}
                <div className="absolute top-[25%] left-[20%] text-center">
                  <span className="inline-block h-1.5 w-1.5 bg-slate-605 rounded-full" style={{ backgroundColor: "#64748B" }} />
                  <p className="text-[9px] text-slate-400 font-bold font-display uppercase scale-90">Sopore</p>
                </div>

                {/* Ganderbal node */}
                <div className="absolute top-[20%] right-[30%] text-center">
                  <span className="inline-block h-1.5 w-1.5 bg-slate-605 rounded-full" style={{ backgroundColor: "#64748B" }} />
                  <p className="text-[9px] text-slate-400 font-bold font-display uppercase scale-90">Ganderbal</p>
                </div>

                {/* Gulmarg node */}
                <div className="absolute bottom-[35%] left-[15%] text-center">
                  <span className="inline-block h-1.5 w-1.5 bg-slate-605 rounded-full" style={{ backgroundColor: "#64748B" }} />
                  <p className="text-[9px] text-slate-400 font-bold font-display uppercase scale-90">Gulmarg</p>
                </div>

                {/* Anantnag node */}
                <div className="absolute bottom-[20%] right-[20%] text-center">
                  <span className="inline-block h-1.5 w-1.5 bg-slate-605 rounded-full" style={{ backgroundColor: "#64748B" }} />
                  <p className="text-[9px] text-slate-400 font-bold font-display uppercase scale-90">Anantnag</p>
                </div>

                {/* CENTRAL HUB SRINAGAR, LAL CHOWK */}
                <div className="absolute top-[46%] left-[46%] text-center z-10 flex flex-col items-center">
                  {/* Concentric red expanding circles */}
                  <div className="relative flex h-4 w-4 items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sport-red opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-sport-red" />
                  </div>
                  <p className="text-[10px] text-white font-extrabold font-display uppercase mt-1 tracking-tight">LAL CHOWK (SRINAGAR)</p>
                  <p className="text-[8px] text-sport-blue font-black tracking-widest font-sans uppercase">S+MED CENTER</p>
                </div>
              </div>
            </div>

            {/* Travel estimations widget */}
            <div className="space-y-3 relative z-10">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-slate-400 font-display">
                Drive Guide to Showroom
              </h4>

              <div className="space-y-2 max-h-40 overflow-y-auto">
                {transitRoutes.map((route, i) => (
                  <div key={i} className="flex justify-between items-center text-xs bg-slate-950/40 p-2 rounded-xl border border-slate-800/60 font-sans">
                    <span className="text-slate-350 font-medium">from {route.from}</span>
                    <div className="flex gap-2.5 items-center font-bold">
                      <span className="text-[11px] text-slate-450">{route.dist}</span>
                      <span className="text-sport-red font-display uppercase text-[10px] flex items-center gap-1">
                        <ArrowRight className="h-2.5 w-2.5" />
                        {route.time}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
