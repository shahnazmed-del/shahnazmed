import React from "react";
import { motion } from "motion/react";
import { Shield, Sparkles, Phone, ChevronRight, Activity, Zap } from "lucide-react";
import { STORE_INFO } from "../data";

interface HeroSectionProps {
  onExploreProducts: () => void;
  onContactClick: () => void;
}

export default function HeroSection({ onExploreProducts, onContactClick }: HeroSectionProps) {
  return (
    <div className="relative bg-slate-950 overflow-hidden" id="shahnazmed-hero-section">
      {/* Background Decorative grids & gradients */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(10,78,155,0.22),rgba(255,255,255,0))]" />
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-sport-blue/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-slate-950 to-transparent" />
        
        {/* Subtle grid pattern for sporty technical texture */}
        <div className="absolute inset-0 opacity-[0.03] bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:24px_24px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-20 sm:pb-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Text Content */}
          <div className="lg:col-span-7 text-left space-y-8">
            {/* Promo Tag */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 bg-sport-blue/10 border border-sport-blue/30 px-3.5 py-1.5 rounded-full text-sport-blue text-xs font-semibold uppercase tracking-wider font-display"
            >
              <Activity className="h-3.5 w-3.5 animate-pulse text-sport-red" />
              <span>Srinagar's Premier Sports Medicine & Recovery Hub</span>
            </motion.div>

            {/* Main Title Headers */}
            <div className="space-y-4">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-none font-display uppercase"
              >
                Engineered for <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sport-blue via-blue-400 to-sport-red">
                  Performance.
                </span>
                <br />
                Engineered for <span className="text-white border-b-4 border-sport-red pb-1">Recovery.</span>
              </motion.h1>

              <motion.p 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="text-slate-300 text-lg max-w-xl font-light leading-relaxed"
              >
                {STORE_INFO.about}
              </motion.p>
            </div>

            {/* Quick trust badges */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="grid grid-cols-3 gap-4 border-y border-slate-800/80 py-4 max-w-lg"
            >
              <div className="text-left">
                <p className="text-xl sm:text-2xl font-extrabold text-white font-display">15,000+</p>
                <p className="text-slate-400 text-xs uppercase tracking-wider">Joints Protected</p>
              </div>
              <div className="text-left border-l border-slate-800/80 pl-4">
                <p className="text-xl sm:text-2xl font-extrabold text-sport-blue font-display">100%</p>
                <p className="text-slate-400 text-xs uppercase tracking-wider">Clinical Grade</p>
              </div>
              <div className="text-left border-l border-slate-800/80 pl-4">
                <p className="text-xl sm:text-2xl font-extrabold text-sport-red font-display">Active</p>
                <p className="text-slate-400 text-xs uppercase tracking-wider">Compression</p>
              </div>
            </motion.div>

            {/* Action Buttons */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2"
            >
              <button
                onClick={onExploreProducts}
                className="sport-gradient-blue text-white hover:bg-opacity-90 font-bold px-7 py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-[0_4px_20px_-4px_rgba(10,78,155,0.5)] cursor-pointer group font-display uppercase tracking-wider text-sm"
              >
                <span>Shop Support Gear</span>
                <ChevronRight className="h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
              </button>
              
              <button
                onClick={onContactClick}
                className="bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/60 font-semibold px-6 py-4 rounded-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer font-display uppercase tracking-wider text-sm"
              >
                <Phone className="h-4 w-4 text-sport-red" />
                <span>Contact Srinagar Fitting Room</span>
              </button>
            </motion.div>
          </div>

          {/* Dynamic Interactive Panel / Graphic Mockup depicting product quality */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-5 relative"
          >
            {/* Athletic Visual Banner Backcard */}
            <div className="relative rounded-3xl overflow-hidden bg-slate-900/60 border border-slate-800 p-3 shadow-2xl backdrop-blur-sm">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] sm:aspect-square bg-slate-950">
                <img 
                  src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=800" 
                  alt="S+Med Performance Athletic Supports"
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                />
                
                {/* Radial gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                
                {/* floating badge 1 */}
                <div className="absolute top-4 left-4 bg-slate-950/90 border border-slate-800/80 px-3.5 py-2.5 rounded-xl shadow-lg flex items-center gap-2.5">
                  <div className="h-8 w-8 rounded-full bg-sport-blue/10 flex items-center justify-center border border-sport-blue/30">
                    <Shield className="h-4 w-4 text-sport-blue" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider leading-none">ANATOMICAL BRACE</p>
                    <p className="text-xs text-white font-extrabold font-display uppercase">3D Knit Protection</p>
                  </div>
                </div>

                {/* floating badge 2 */}
                <div className="absolute bottom-4 right-4 bg-slate-950/90 border border-slate-800/80 px-3.5 py-2.5 rounded-xl shadow-lg flex items-center gap-2.5">
                  <div className="h-8 w-8 rounded-full bg-sport-red/10 flex items-center justify-center border border-sport-red/30">
                    <Zap className="h-4 w-4 text-sport-red" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider leading-none">SPONSOR</p>
                    <p className="text-xs text-white font-extrabold font-display uppercase">Kashmiri Athletes</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Glowing background halos */}
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-sport-blue/10 rounded-full blur-3xl -z-10" />
            <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-sport-red/10 rounded-full blur-3xl -z-10" />
          </motion.div>

        </div>
      </div>
    </div>
  );
}
