import React from "react";
import { Star, ShieldAlert, ShoppingCart, Eye, ArrowUpRight } from "lucide-react";
import { Product } from "../types";

interface ProductCardProps {
  key?: string;
  product: Product;
  onViewDetails: (product: Product) => void;
  onAddToCart: (product: Product, size: string) => void;
}

export default function ProductCard({ product, onViewDetails, onAddToCart }: ProductCardProps) {
  // Select first size as default for rapid addition
  const defaultSize = product.sizes[0];

  // Map support levels to color tags
  const supportLevelColor = {
    Light: "bg-emerald-50 text-emerald-700 border-emerald-200/50",
    Moderate: "bg-blue-50 text-blue-700 border-blue-200/50",
    High: "bg-amber-50 text-amber-700 border-amber-200/50",
    Maximum: "bg-rose-50 text-rose-700 border-rose-200/50",
    Therapeutic: "bg-purple-50 text-purple-700 border-purple-200/50"
  }[product.supportLevel] || "bg-slate-50 text-slate-700 border-slate-200/50";

  return (
    <div 
      className="group bg-white rounded-3xl border border-slate-100 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden" 
      id={`product-card-${product.id}`}
    >
      {/* Product Image Stage */}
      <div className="relative aspect-4/3 overflow-hidden bg-slate-50">
        <img 
          src={product.images[0]} 
          alt={product.name}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />

        {/* Overlays: Best Seller, New Arrival badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {product.isBestSeller && (
            <span className="bg-sport-red text-white text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-lg shadow-sm font-display">
              Bestseller
            </span>
          )}
          {product.isNewArrival && (
            <span className="bg-sport-blue text-white text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-lg shadow-sm font-display">
              New Gear
            </span>
          )}
        </div>

        {/* Support Level Overlay Badge */}
        <div className="absolute bottom-4 left-4">
          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border ${supportLevelColor} shadow-xs font-display`}>
            <ShieldAlert className="h-3 w-3" />
            <span>{product.supportLevel} Spec</span>
          </span>
        </div>

        {/* Hover quick action overlay */}
        <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
          <button
            onClick={() => onViewDetails(product)}
            className="bg-white/95 hover:bg-white text-slate-950 font-bold p-3 rounded-full shadow-lg transition-transform hover:scale-110 cursor-pointer"
            title="Quick View Products"
          >
            <Eye className="h-4.5 w-4.5" />
          </button>
        </div>
      </div>

      {/* Product Info Block */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        
        {/* Category & Ratings Block */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-black uppercase tracking-wider text-slate-400 font-display">
            <span>{product.category}</span>
            <div className="flex items-center gap-0.5 text-amber-500 bg-amber-500/5 px-2 py-0.5 rounded-md">
              <Star className="h-3 w-3 fill-amber-500" />
              <span>{product.rating}</span>
            </div>
          </div>

          {/* Product Name */}
          <h3 
            onClick={() => onViewDetails(product)}
            className="text-slate-950 font-bold font-display uppercase tracking-tight text-lg line-clamp-1 group-hover:text-sport-blue transition-colors cursor-pointer flex items-center justify-between"
          >
            <span>{product.name}</span>
            <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity text-sport-blue" />
          </h3>

          <p className="text-slate-500 text-xs line-clamp-2 leading-relaxed">
            {product.tagline}
          </p>
        </div>

        {/* Sizes Pill Row Preview */}
        <div className="space-y-1.5">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-display">Available Sizes</p>
          <div className="flex flex-wrap gap-1.5">
            {product.sizes.map((size) => (
              <span 
                key={size}
                className="text-[11px] font-semibold text-slate-600 bg-slate-50 border border-slate-200/50 px-2.5 py-0.5 rounded-md"
              >
                {size}
              </span>
            ))}
          </div>
        </div>

        {/* Price & Primary Call to Action buttons */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-4">
          <div className="flex flex-col">
            <span className="text-xs text-slate-400 line-through leading-none">
              {product.originalPrice ? `₹${product.originalPrice}` : ""}
            </span>
            <span className="text-xl font-black text-slate-950 font-display leading-none mt-1">
              ₹{product.price}
            </span>
          </div>

          <button
            onClick={() => onAddToCart(product, defaultSize)}
            className="bg-slate-950 hover:bg-sport-blue text-white hover:text-white font-bold p-3 sm:px-4 rounded-xl flex items-center gap-2 transition-all cursor-pointer group/btn"
          >
            <ShoppingCart className="h-4 w-4 transform group-hover/btn:-translate-y-0.5 transition-transform" />
            <span className="text-xs font-display uppercase tracking-wider hidden sm:inline">Add to Cart</span>
          </button>
        </div>

      </div>
    </div>
  );
}
