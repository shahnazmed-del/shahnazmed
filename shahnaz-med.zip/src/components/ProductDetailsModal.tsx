import React, { useState } from "react";
import { X, Check, ShoppingCart, ShieldAlert, Star, Layers, Activity, HelpCircle } from "lucide-react";
import { Product, ColorOption } from "../types";

interface ProductDetailsModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, color: ColorOption, quantity: number) => void;
}

export default function ProductDetailsModal({ product, onClose, onAddToCart }: ProductDetailsModalProps) {
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState<ColorOption>(product.colors[0]);
  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<"overview" | "specs" | "benefits">("overview");
  const [activeImageIdx, setActiveImageIdx] = useState<number>(0);

  const incrementQty = () => setQuantity((prev) => prev + 1);
  const decrementQty = () => setQuantity((prev) => Math.max(1, prev - 1));

  const handleAddToCart = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6" 
      id="product-detail-modal-container"
    >
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity cursor-pointer" 
        onClick={onClose} 
      />

      {/* Modal Card content wrapper */}
      <div className="relative bg-white w-full max-w-4xl rounded-3xl overflow-hidden shadow-2xl border border-slate-100 flex flex-col md:flex-row z-10 max-h-[90vh] md:max-h-[85vh]">
        
        {/* Close Button top corner */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 bg-slate-100 hover:bg-sport-red hover:text-white text-slate-500 rounded-full p-2 transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Column 1: Image Showcase */}
        <div className="md:w-1/2 bg-slate-50 p-6 flex flex-col justify-center border-b md:border-b-0 md:border-r border-slate-100 overflow-y-auto">
          <div className="aspect-4/3 sm:aspect-square rounded-2xl overflow-hidden bg-white border border-slate-100 relative">
            <img 
              src={product.images[activeImageIdx] || product.images[0]} 
              alt={product.name}
              className="w-full h-full object-cover transition-all"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Image thumbnails column, if multiple exists */}
          {product.images.length > 1 && (
            <div className="flex gap-2.5 mt-3 justify-center">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`w-14 h-14 rounded-xl overflow-hidden border-2 cursor-pointer transition-all ${idx === activeImageIdx ? "border-sport-blue scale-102" : "border-transparent opacity-60"}`}
                >
                  <img src={img} className="w-full h-full object-cover" referrerPolicy="no-referrer" alt="" />
                </button>
              ))}
            </div>
          )}

          {/* Sizing Information Drawer / Chart Quick helper */}
          <div className="mt-6 bg-blue-50/50 border border-blue-100 rounded-2xl p-4">
            <div className="flex gap-2 items-start">
              <HelpCircle className="h-4.5 w-4.5 text-sport-blue shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-display">How to Choose Size?</h4>
                <p className="text-[11px] text-slate-600 leading-normal">
                  Measure around the target area with a soft tape. Sizing fits tight to enforce anatomical compression; if you are borderline, choose one size up for comfort.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Column 2: Detailed Selection Forms */}
        <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto">
          <div className="space-y-6">
            
            {/* Header Product Info */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-sport-blue bg-sport-blue/5 border border-sport-blue/10 px-2.5 py-1 rounded-md inline-block font-display">
                {product.category}
              </span>
              
              <h2 className="text-2xl sm:text-3xl font-black text-slate-950 font-display uppercase tracking-tight">
                {product.name}
              </h2>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-0.5 text-amber-500 font-bold text-sm bg-amber-500/5 px-2 py-0.5 rounded-lg border border-amber-500/10">
                  <Star className="h-4 w-4 fill-amber-500" />
                  <span>{product.rating}</span>
                </div>
                <span className="text-xs text-slate-400 font-medium font-sans">
                  ({product.reviewsCount} verified reviews)
                </span>
              </div>
            </div>

            {/* Pricing Section */}
            <div className="flex items-baseline gap-2.5 bg-slate-50 border border-slate-100 p-3.5 rounded-2xl">
              <span className="text-3xl font-black text-slate-950 font-display">
                ₹{product.price}
              </span>
              {product.originalPrice && (
                <>
                  <span className="text-sm text-slate-400 line-through">
                    ₹{product.originalPrice}
                  </span>
                  <span className="text-xs font-bold font-display text-sport-red uppercase ml-auto">
                    Save {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% Today
                  </span>
                </>
              )}
            </div>

            {/* Sizes Selection radio pill row */}
            <div className="space-y-2">
              <div className="flex items-baseline justify-between">
                <label className="text-xs font-black uppercase tracking-wider text-slate-900 font-display">
                  Select Fitment Size
                </label>
                <span className="text-[10px] font-semibold text-slate-400 font-sans">
                  Fits true-to-compression
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setSelectedSize(size)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                      selectedSize === size
                        ? "border-slate-950 bg-slate-950 text-white font-black"
                        : "border-slate-200 bg-white text-slate-600 hover:border-slate-400"
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Colors Selection circle options */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-wider text-slate-900 font-display block">
                Select Accent Color: <span className="text-slate-500 font-medium normal-case font-sans">{selectedColor.name}</span>
              </label>
              <div className="flex gap-3">
                {product.colors.map((color) => (
                  <button
                    key={color.name}
                    type="button"
                    onClick={() => setSelectedColor(color)}
                    className={`w-9 h-9 rounded-full border-3 flex items-center justify-center transition-all cursor-pointer ${
                      selectedColor.name === color.name ? "border-slate-950 scale-102" : "border-slate-200"
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  >
                    {selectedColor.name === color.name && (
                      <Check className={`h-4.5 w-4.5 ${color.hex === "#FFFFFF" ? "text-slate-950" : "text-white"}`} strokeWidth={3} />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Tabs for Overview, Specifications, and Benefits */}
            <div className="space-y-3">
              <div className="flex border-b border-slate-100 gap-6">
                {(["overview", "specs", "benefits"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`pb-2 text-xs font-black uppercase tracking-wider font-display transition-all border-b-2 cursor-pointer ${
                      activeTab === tab
                        ? "border-sport-blue text-sport-blue"
                        : "border-transparent text-slate-400 hover:text-slate-600"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              {/* Tab Outputs */}
              <div className="text-xs text-slate-600 leading-relaxed min-h-[100px]">
                {activeTab === "overview" && (
                  <div className="space-y-2 animation-fade">
                    <p className="font-semibold text-slate-800 italic">{product.tagline}</p>
                    <p>{product.longDescription}</p>
                  </div>
                )}
                
                {activeTab === "specs" && (
                  <ul className="space-y-2 list-none p-0 animation-fade font-sans">
                    {product.specs.map((spec, i) => (
                      <li key={i} className="flex gap-2 items-start border-l-2 border-slate-200 pl-2.5 py-0.5">
                        <Layers className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                        <span>{spec}</span>
                      </li>
                    ))}
                  </ul>
                )}
                
                {activeTab === "benefits" && (
                  <ul className="space-y-2 list-none p-0 animation-fade font-sans">
                    {product.benefits.map((benefit, i) => (
                      <li key={i} className="flex gap-2.5 items-start bg-emerald-500/5 text-emerald-950 p-2 rounded-xl border border-emerald-500/10">
                        <Activity className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="font-medium">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

          </div>

          {/* Sticky Interactive Add trigger box */}
          <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between gap-4">
            <div className="flex items-center border border-slate-250 rounded-xl overflow-hidden shrink-0">
              <button
                onClick={decrementQty}
                className="px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100 font-extrabold text-slate-700 transition-colors cursor-pointer"
              >
                -
              </button>
              <span className="px-4 py-2 text-sm font-bold text-slate-950 font-display">
                {quantity}
              </span>
              <button
                onClick={incrementQty}
                className="px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100 font-extrabold text-slate-700 transition-colors cursor-pointer"
              >
                +
              </button>
            </div>

            <button
              onClick={handleAddToCart}
              className="flex-1 bg-slate-950 hover:bg-sport-blue text-white hover:text-white font-bold py-3.5 px-6 rounded-xl flex items-center justify-center gap-2.5 transition-all text-sm uppercase tracking-wider font-display cursor-pointer"
            >
              <ShoppingCart className="h-4.5 w-4.5" />
              <span>Add to Cart (₹{product.price * quantity})</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
