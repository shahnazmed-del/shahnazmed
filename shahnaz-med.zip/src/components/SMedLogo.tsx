import React from "react";

interface SMedLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  lightText?: boolean;
}

export default function SMedLogo({ className = "", size = "md", lightText = false }: SMedLogoProps) {
  // Determine height/width based on size preset
  const sizeClasses = {
    sm: "h-8",
    md: "h-10",
    lg: "h-14",
    xl: "h-20"
  };

  return (
    <div className={`flex items-center gap-1.5 font-display select-none ${sizeClasses[size]} ${className}`} id="smed-logo-container">
      {/* S */}
      <span className="text-sport-blue font-black tracking-tighter text-current leading-none flex items-center translate-y-[2%] select-none font-display" 
            style={{ fontSize: size === "sm" ? "1.8rem" : size === "md" ? "2.4rem" : size === "lg" ? "3.2rem" : "4.5rem", color: "#0A4E9B" }}>
        S
      </span>

      {/* Shield with plus */}
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-auto aspect-square overflow-visible"
        style={{ maxHeight: size === "sm" ? "24px" : size === "md" ? "34px" : size === "lg" ? "48px" : "64px" }}
      >
        {/* Shield Border */}
        <path
          d="M50 12 C68 12, 78 18, 86 28 C86 58, 70 82, 50 88 C30 82, 14 58, 14 28 C22 18, 32 12, 50 12 Z"
          stroke="#0A4E9B"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        {/* Plus Sign */}
        <path
          d="M50 32 V68 M32 50 H68"
          stroke="#0A4E9B"
          strokeWidth="11"
          strokeLinecap="round"
        />
      </svg>

      {/* Med */}
      <span className="font-extrabold tracking-tight text-current leading-none flex items-center translate-y-[1%] select-none font-display"
            style={{ 
              fontSize: size === "sm" ? "1.8rem" : size === "md" ? "2.4rem" : size === "lg" ? "3.2rem" : "4.5rem",
              color: lightText ? "#FFFFFF" : "#A80D1A" 
            }}>
        Med
      </span>
    </div>
  );
}
