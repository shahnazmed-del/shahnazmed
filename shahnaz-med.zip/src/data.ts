import { Product, StoreReview } from "./types";

export const STORE_INFO = {
  name: "Shahnaz Med",
  location: "Main Showroom near Lal Chowk, Srinagar, Jammu & Kashmir, 190001",
  city: "Srinagar, J&K",
  phone: "9103681134",
  email: "shahnazmed@gmail.com",
  whatsapp: "+919103681134",
  tagline: "Engineered for Performance. Engineered for Recovery.",
  about: "Based in the heart of Srinagar, Jammu & Kashmir, Shahnaz Med is Kashmir's premier athletic orthopedics & compression wear hub. We fuse clinical-grade orthopedic technology with standard athletic sports designs to keep active athletes, health-conscious fitness enthusiasts, and recovering patients moving without boundary. From Lal Chowk to the peaks of Gulmarg, we support your active lifestyle."
};

export const INSTORE_ADVANTAGES = [
  {
    title: "Srinagar Base",
    description: "Centrally located at Lal Chowk. Fast in-person sizing consultations and premium customer care."
  },
  {
    title: "Sports Fitment",
    description: "Engineered specifically for active athletes, weightlifters, trekkers, and post-surgery rehabilitation."
  },
  {
    title: "Clinical Grade",
    description: "Doctor-recommended therapeutic contouring, breathable neoprene weaves, and non-slip silicone linings."
  },
  {
    title: "Direct Purchase Support",
    description: "Easy order dispatch across J&K, plus fast inquiries via WhatsApp or direct phone calls."
  }
];

export const COLOR_PRESETS = {
  red: { name: "Athletic Red", hex: "#A80D1A" },
  blue: { name: "Sport Blue", hex: "#0A4E9B" },
  slate: { name: "Carbon Slate", hex: "#1E293B" },
  charcoal: { name: "Midnight Black", hex: "#0F172A" },
  grey: { name: "Cool Grey", hex: "#64748B" },
  white: { name: "Pure White", hex: "#FFFFFF" }
};

export const STORE_PRODUCTS: Product[] = [
  {
    id: "wrist-band-01",
    name: "S+Med ForceGrip Compression Wrist Band",
    category: "Gym & Fitness Gear",
    price: 349,
    originalPrice: 499,
    tagline: "Heavy-duty dual wrist strap with reinforced thumb lock for extreme lifting stability.",
    description: "Designed for weightlifters, powerlifters, rackets, and gym enthusiasts, this wrist band utilizes an elasticized, heavy weaved band to lock the carpal joints under high tension loads. Eliminates hyperextension during bench presses, shoulder presses, and heavy bar actions.",
    longDescription: "The S+Med ForceGrip Compression Wrist Band is an essential addition to any high-intensity training bag. Crafted with breathable, high-stretch elasticized yarn, this wrist support incorporates an adjustable industrial-grade hook-and-loop closure, letting athletes dial in their specific level of compression. By offering optimal rigidness without cutting off blood flow, it keeps your wrists protected during competitive lifts or intensive rehabilitation. The reinforced thumb-loop guarantees the band stays centered, preventing uncomfortable shifting or twisting mid-lift.",
    images: [
      "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=600",
      "https://images.unsplash.com/photo-1600881198608-d890408573dc?auto=format&fit=crop&q=80&w=600"
    ],
    sizes: ["Adjustable (One Size Fits All)"],
    colors: [COLOR_PRESETS.blue, COLOR_PRESETS.red, COLOR_PRESETS.charcoal],
    supportLevel: "Moderate",
    supportRating: 3.5,
    rating: 4.8,
    reviewsCount: 142,
    specs: [
      "Material: Heavy Elasticized cotton/polyester yarn blends with micro-reinforced stitching",
      "Closure: High-strength micro-velcro closure for custom pressure regulation",
      "Dimensions: 18 inches total length, 3 inches safety athletic width",
      "Specialty: Extra-reinforced thumb-loop for instant, single-handed fitment adjustment"
    ],
    benefits: [
      "Prevents painful carpal hyperextension during maximum bench or overhead press sets",
      "Absorbs heavy vibrations and disperses shock loads evenly through wrist joints",
      "High comfort design reduces tendon strain during long kettlebell or racket workouts",
      "Anti-sweat breathable active knitting limits irritation under heavy perspiration"
    ],
    isBestSeller: true
  },
  {
    id: "knee-cap-02",
    name: "S+Med ActiveShield 3D Neoprene Knee Cap",
    category: "Orthopedic Supports",
    price: 599,
    originalPrice: 899,
    tagline: "Sub-patellar compression ring with dual micro-stabilizers for peak joint protection.",
    description: "The primary armor for runner's knee, patellar tendonitis, and arthritis discomfort. Developed with modern 3D anatomical knitting and a silicone knee ring, it braces the patella to distribute dynamic energy safely.",
    longDescription: "Constructed with professional-grade neoprene weave and integrated spiral stabilizers, the S+Med ActiveShield Knee Cap offers targeted knee-cap compression. It aids in dispersing pressure in key ligaments (ACL/PCL/MCL). High-intensity cross-stretching ensures compression is targeted primarily to the joint without cutting off range of motion. Ideal for kashmiri mountain trekkers, daily marathon runners, gym weight trainers, and adults needing pain-free mobility during winter months in J&K.",
    images: [
      "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&q=80&w=600"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: [COLOR_PRESETS.charcoal, COLOR_PRESETS.blue],
    supportLevel: "High",
    supportRating: 4.5,
    rating: 4.9,
    reviewsCount: 218,
    specs: [
      "Material: High-elastic nylon blend with eco-neoprene core and hyper-breathable back flex mesh",
      "Patella Comfort: Medical-grade soft circular silicone ring to cradle the kneecap snugly",
      "Stabilizers: Dynamic plastic side bones stitched tightly on either side to control side-movement",
      "Anti-Slip: Dual wave silicone anti-strip grip lines to stop sliding or buckling while running"
    ],
    benefits: [
      "Encourages active oxygenated blood flow to speed dynamic recovery times",
      "Suppresses lateral knee wobble during deep high-bar squats or trail running descents",
      "Reduces chronic patellar knee shifting and controls tendon friction pain",
      "Insulating neoprene core retains natural healing warmth for stiff joints during winter"
    ],
    isBestSeller: true,
    isNewArrival: false
  },
  {
    id: "pillow-03",
    name: "S+Med PostureGuard Cervical Contour Pillow",
    category: "Spine & Neck Care",
    price: 1399,
    originalPrice: 1999,
    tagline: "Therapeutic orthopedic high-density memory foam to align spine and relieve neck strain.",
    description: "Waking up with stiff neck muscles or tension headaches is a sign of incorrect cervical alignment. This orthopedic pillow cradles the neck profile perfectly to unlock neck strain and correct sleeping posture.",
    longDescription: "Our signature Spine Care product, the PostureGuard Cervical Contour Pillow, utilizes temperature-responsive high-density memory foam. Its unique butterfly-shaped multi-zone design offers dual height settings on either side to accommodate both back-sleepers and side-sleepers. By contouring cleanly to the skull base and cervical spine curve, it stretches squeezed neck muscles, expands neural paths, and minimizes morning rigidity. Comes wrapped in a hypoallergenic, extremely breathable zip-removable winter-cozy cover.",
    images: [
      "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=600"
    ],
    sizes: ["Standard", "Queen Contour"],
    colors: [COLOR_PRESETS.white, COLOR_PRESETS.grey],
    supportLevel: "Therapeutic",
    supportRating: 5.0,
    rating: 4.7,
    reviewsCount: 189,
    specs: [
      "Material: premium non-deforming 50D high-density thermo-sensitive memory foam",
      "Zones: Neck support roll, head alignment pit, shoulder-cut side sleeper wings",
      "Dimensions: 24 x 14 x 4.8 / 3.9 inches (Dual-level cervical height support)",
      "Cover: Soft, anti-allergen washable sport-knit mesh cover with heavy-duty zipper"
    ],
    benefits: [
      "Maintains natural cervical spine curvature to relieve neck pain and muscle rigidity",
      "Dramatically reduces muscle tension, snoring, and pressure points for restorative sleep",
      "Allows targeted dual cervical angle heights suited to personal shoulder widths",
      "Stays firm and hyper-supportive across seasons without hardening in Kashmiri winter"
    ],
    isBestSeller: false,
    isNewArrival: true
  },
  {
    id: "gloves-04",
    name: "S+Med ProCombat Gym & Weightlifting Gloves",
    category: "Gym & Fitness Gear",
    price: 649,
    originalPrice: 999,
    tagline: "Double-layered silicone palm print with integrated 12-inch heavy wrist wrap strap.",
    description: "Engineered specifically for heavy pulling, dumbbell workouts, and chin-up bars. Shields palms from tears, calluses, and sliding under high weight stress, backed by wrist safety wrap.",
    longDescription: "The S+Med ProCombat Weightlifting Gloves combine absolute palm protection with built-in sport wrist stabilization. Made using high-tensile microfiber, the palm features a thick honeycomb-patterned silicone gel layer that bonds to steel barbell knurling. The open back-of-hand construction is highly breathable, promoting airflow and preventing sweat buildup during grueling sets. The attached heavy-duty wrist wraps replace the need for separate wrist wraps, optimizing support during combined curl/press exercise routines.",
    images: [
      "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&q=80&w=600"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: [COLOR_PRESETS.charcoal, COLOR_PRESETS.red],
    supportLevel: "Moderate",
    supportRating: 3.8,
    rating: 4.7,
    reviewsCount: 95,
    specs: [
      "Material: Ultra-breathable Lycra backing, hard-wearing reinforced microfiber palms",
      "Palm Grip: Anti-skid honeycomb patterned 3mm thick silicone pad overlay",
      "Strap: Built-in 12-inch high tension elasticized compression wrist protection wrap",
      "Pull-Tabs: Integrated finger tabs for painless glove removal post-lifting"
    ],
    benefits: [
      "Protects hands against calluses, painful gym blisters, and palm friction burns",
      "Secures an ironclad grip on barbells, preventing slippage caused by sweaty hands",
      "Combines standard grip gloves with functional heavy duty joint support wrap benefits",
      "Flexible pull-tabs permit stripping off gloves seamlessly after exhausting workouts"
    ],
    isBestSeller: false,
    isNewArrival: false
  },
  {
    id: "ankle-05",
    name: "S+Med KineticLock Ankle Stabilizer",
    category: "Orthopedic Supports",
    price: 399,
    originalPrice: 599,
    tagline: "Figure-8 crisscross compression strap to secure ankles against dynamic sport sprains.",
    description: "The ultimate prevention for dynamic ankle rolling and chronic strain. Features lightweight breathable mesh that slips easily into athletic shoes while enforcing professional orthopedic brace safety.",
    longDescription: "The S+Med KineticLock Ankle Stabilizer offers professional protection for high-risk twisting sports like soccer, basketball, tennis, and trekking. Its low-profile sleeve design is paired with dual adjustable elastane straps winding in a figure-8, mimicking orthopedic athletic taping. By keeping the talotarsal joint aligned and applying continuous light pressure, it reduces ankle instability and speeds recovery of sprained ankles.",
    images: [
      "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&q=80&w=600"
    ],
    sizes: ["M", "L", "XL"],
    colors: [COLOR_PRESETS.charcoal, COLOR_PRESETS.grey],
    supportLevel: "High",
    supportRating: 4.2,
    rating: 4.8,
    reviewsCount: 74,
    specs: [
      "Material: Hyper-thin nylon spandex flat knitting with high recovery stretch tension",
      "Strap System: Dual high-elastic figure-8 cruz-wraps styled with micro hook-valc",
      "Thickness: Under 1.5mm thickness - completely unnoticeable inside athletic shoes",
      "Design: Open heel layout for natural ankle movement and precise joint feedback"
    ],
    benefits: [
      "Secures talus bone alignment to stop inner and outer ankle rolled injuries",
      "Minimizes structural instability on uneven fields, rocky kashmiri mountain paths",
      "Provides targeted compression to bring down swollen tendon nodes instantly",
      "Low profile stitch easily pairs with running shoes, sneakers, or football spikes"
    ],
    isNewArrival: true
  },
  {
    id: "back-06",
    name: "S+Med PowerSpine Lumbar Posture Belt",
    category: "Spine & Neck Care",
    price: 1199,
    originalPrice: 1799,
    tagline: "Quad carbon-fiber stays with dual outer pulley straps to align lower back posture.",
    description: "Designed for deadlifters, workers lifting heavy cargo, and people suffering from slip-discs. Locks the spine to lumbar zone to correct compression and posture immediately.",
    longDescription: "Offering maximal therapeutic lumbar stabilization, the S+Med PowerSpine Posture Belt utilizes 4 anatomical orthopedic supports aligned with back muscles. The outer double pull-belt pulleys amplify tightening force by 3x, drawing the abdomen inward to reduce load on lower-back discs. Helps to maintain professional ergonomics during heavy deadlifts, gym training sessions, or long hours sitting at work.",
    images: [
      "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=600"
    ],
    sizes: ["M (28-34)", "L (34-40)", "XL (40-46)", "XXL (46-52)"],
    colors: [COLOR_PRESETS.charcoal, COLOR_PRESETS.blue],
    supportLevel: "Maximum",
    supportRating: 4.9,
    rating: 4.9,
    reviewsCount: 156,
    specs: [
      "Stays: 4 rigid ergonomic carbon-fiber stays designed to follow human vertebrae structure",
      "Tightening System: High-gear double elastic pull bands for targeted abdominal bracing",
      "Height: 9-inch lumbar coverage for optimal spine and pelvis stability",
      "Material: Heavy duty military fabric blends with non-stretching industrial stitch"
    ],
    benefits: [
      "Forces a safe back posture to eliminate spinal compression under high muscle strains",
      "Eliminates painful lumbar pinching during heavy deadlifts or repetitive daily lifting",
      "Speeds herniated disc, sciatica, and lower lumbar muscle strain rehabilitation",
      "Breathable high-strength industrial mesh minimizes heat traps during gym routines"
    ],
    isBestSeller: true
  }
];

export const CUSTOMER_REVIEWS: StoreReview[] = [
  {
    id: "rev-01",
    author: "Zubair Ahmad",
    location: "Srinagar, J&K",
    rating: 5,
    daysAgo: 3,
    comment: "Excellent knee support! I used the S+Med ActiveShield Knee Cap for my trekking trip to Great Lakes of Kashmir. Absolute lifesaver on steep climbs and rocky descents, knee stayed completely stabilized.",
    verified: true,
    activity: "Trekker & Runner"
  },
  {
    id: "rev-02",
    author: "Imran Khan",
    location: "Karan Nagar, Srinagar",
    rating: 5,
    daysAgo: 7,
    comment: "The ForceGrip Wrist wraps are phenomenal. Bench pressing 120kg was causing deep joint ache, but these bands locked my carpal bones perfectly tight. Shahnaz Med's team at Lal Chowk provided superb sizing help.",
    verified: true,
    activity: "Powerlifter"
  },
  {
    id: "rev-03",
    author: "Dr. Tabasum Ara",
    location: "Srinagar",
    rating: 5,
    daysAgo: 12,
    comment: "I regularly refer my cervical pain and sciatica patients to Shahnaz Med. Their PostureGuard Cervical Pillow is medical grade memory foam that keeps the spine straight. The support stays intact even after months of sleep.",
    verified: true,
    activity: "Consulting Physiotherapist"
  },
  {
    id: "rev-04",
    author: "Bilal Dar",
    location: "Sopore, J&K",
    rating: 4,
    daysAgo: 16,
    comment: "Great gym gloves with built-in wraps. The silicone grid grip adheres to gym dumbbells like glue. Shipped right to my doorstep in Sopore in just one day. Extremely reliable service!",
    verified: true,
    activity: "Calisthenics Coach"
  }
];
