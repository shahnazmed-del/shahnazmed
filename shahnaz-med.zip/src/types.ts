export type ProductCategory = "Orthopedic Supports" | "Spine & Neck Care" | "Gym & Fitness Gear";

export interface ColorOption {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;
  originalPrice?: number;
  description: string;
  longDescription: string;
  tagline: string;
  images: string[];
  sizes: string[];
  colors: ColorOption[];
  supportLevel: "Light" | "Moderate" | "High" | "Maximum" | "Therapeutic";
  supportRating: number; // 1-5 scale for slider
  rating: number;
  reviewsCount: number;
  specs: string[];
  benefits: string[];
  isBestSeller?: boolean;
  isNewArrival?: boolean;
}

export interface CartItem {
  id: string; // unique combination of product.id + selectedSize + selectedColor.name
  product: Product;
  selectedSize: string;
  selectedColor: ColorOption;
  quantity: number;
}

export interface StoreReview {
  id: string;
  author: string;
  location: string;
  rating: number;
  daysAgo: number;
  comment: string;
  verified: boolean;
  activity: string;
}

export interface InquiryFormState {
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
  productName?: string;
}
